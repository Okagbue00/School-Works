

#ifndef SOLUTIONS_RANDOMINDEX_H
#define SOLUTIONS_RANDOMINDEX_H

/*
 * Return a random integer between 0 and n-1.
 */
unsigned int random_index(unsigned int n);


#endif //SOLUTIONS_RANDOMINDEX_H
