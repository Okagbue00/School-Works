/* OKAGBUE ONYEKA FRANCIS
 * CMPT 214
 * Student No: 11279373 */


#include "stdio.h"
#include "math.h"

int main(){
    int initial_expenses = 50 + 10; //expenses spent:- 50 dollars for shelter & 10 dollar for gas
    double expenses = 2 + 1.50; //the total expenses spent; 2 dollar for each meal for the chick & 1.50 dollars cost for each chick
    double chickenPrice = 4.00; //chicken cost per price
    int Profit = 300; //profit maximization
    double ChickenLost = 5/100.0; //chickens that will be lost in 16 weeks in percentage
    int numberOfChickens; //total number of chickens

    //Calculate number of chicken to get profit
    numberOfChickens = (int)(ceil((Profit + initial_expenses) / ((chickenPrice - (ChickenLost * chickenPrice)) - expenses)));\

    printf("The total number of chickens that Mary bought to raise $300: %d\n", numberOfChickens);
    printf("The number of chicks that Mary lost during the first sixteen weeks: %d\n", (int)(ChickenLost * numberOfChickens));
    printf("The total expenses: %f\n", (expenses * numberOfChickens) + initial_expenses);




}
