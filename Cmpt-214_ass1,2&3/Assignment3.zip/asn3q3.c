/* OKAGBUE ONYEKA FRANCIS
 * CMPT 214
 * Student No: 11279373 */


#include "stdio.h"

/**
* @param strawberry: is the amount of strawberry to make smoothies
 * @param juice: is the cups of juice to make smoothies
 * @param sugar: is the tablespoon of sugar to make smoothies
 * @param n: integer number to make smoothies
 * @return integer
 */

int calculateAmountOfIngredients(int *strawberry, double *juice, double *sugar, int num){
    if (num < 0){ //it checks whether the integer  is less than 0 or returns true
        return 1;
    }

    //calculates the amount of strawberries, sugar and juice
    *strawberry = num * 12;
    *juice = num * 1.5;
    *sugar = num * 0.5;

    return 0;
}

int main(){
    //ingredient items of the smoothies

    int strawberries;
    double sugar, juice;

    //n ---- number of smoothies
    int numberOfSmoothies;

    printf("Number of Smoothies: ");
    scanf("%d", &numberOfSmoothies);

// it calls the calculateAmountOfIngredients
// and address variables that hold ingredients

//checks return value
if (!calculateAmountOfIngredients(&strawberries, &juice, &sugar, numberOfSmoothies)){
    //printing the ingredients
    printf("To make %d smoothies\n", numberOfSmoothies);
    printf("We need %d strawberries,\n",strawberries);
    printf("and %f teaspoon of sugar,\n",sugar);
    printf("and %f glass cup of juice,\n",juice);
    printf("Congrats, complete recipe");
} else(printf("No ingredients to make/perform Smoothies.  "));
    return 0;

}
